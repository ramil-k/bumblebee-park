import{default as t}from"../components/pages/_layout.svelte-f30a1f51.js";export{t as component};
