import{default as t}from"../components/error.svelte-aba40dee.js";export{t as component};
