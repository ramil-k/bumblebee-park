import{_ as r}from"./_page-56e74acc.js";import{default as t}from"../components/pages/_page.svelte-2c87fa91.js";export{t as component,r as shared};
