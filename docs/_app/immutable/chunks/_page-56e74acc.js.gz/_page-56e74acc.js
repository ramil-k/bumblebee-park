const e=!0,r=!0,t=Object.freeze(Object.defineProperty({__proto__:null,prerender:!0,ssr:!0},Symbol.toStringTag,{value:"Module"}));export{t as _,e as p,r as s};
